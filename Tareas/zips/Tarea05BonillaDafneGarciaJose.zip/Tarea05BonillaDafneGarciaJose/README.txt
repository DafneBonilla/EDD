Integrantes:
Nombre:                             No. de cuenta   
Dafne Bonilla Reyes            -      319089660   
José Camilo García Ponce       -      319210536  

Organización: Mediante una llamada de discord fuimos leyendo problema por problema llegando a soluciones usando lo aprendido en la clase.
