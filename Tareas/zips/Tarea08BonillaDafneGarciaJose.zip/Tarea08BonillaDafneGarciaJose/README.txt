Integrantes:
Nombre:                             No. de cuenta   
Dafne Bonilla Reyes            -      319089660   
José Camilo García Ponce       -      319210536  

Organización: Por medio una llamada de discord fuimos leyendo los problemas y resolviendolos en un archivo de overleaf, llegando a soluciones, haciendo las operaciones necesaria y usando lo aprendido en la clase; Camilo escribio las descripciones y Dafne realizo las imagenes.
