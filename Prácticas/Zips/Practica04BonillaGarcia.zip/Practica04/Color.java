public enum Color {
    NINGUNO,

    ROJO,

    NEGRO
}