package Apuestas.Estructuras;

public enum Color {
    NINGUNO,

    ROJO,

    NEGRO
}