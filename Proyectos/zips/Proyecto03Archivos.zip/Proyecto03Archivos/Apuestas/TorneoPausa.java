package Apuestas;

/**
 * Clase para representar una excepcion del torneo.
 */
public class TorneoPausa extends Exception {

    /**
     * Constructor vacio.
     */
    public TorneoPausa() {
    }

}